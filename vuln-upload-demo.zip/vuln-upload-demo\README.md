# Demo - Upload de fichier non filtre -> Webshell PHP

Application PHP volontairement vulnerable, pensee pour une demo rapide et
legere sur une VM Windows 10 / Windows Server, afin d'illustrer :

1. une faille d'upload classique (CWE-434 - pas de controle d'extension/MIME),
2. le depot d'un webshell PHP,
3. l'execution de commandes via ce webshell,
4. comment un EDR comme **CrowdStrike Falcon** detecte et bloque ce type
   d'attaque (ecriture de fichier suspect, puis process enfant anormal
   genere par le serveur web).

> ⚠️ A utiliser uniquement dans un lab isole (VM dediee, reseau prive /
> host-only). Ne jamais exposer cette VM sur Internet ou sur le reseau
> de production.

---

## 1. Pre-requis (VM Windows)

Le plus leger pour Windows : **PHP seul**, sans IIS complet.

### Option A - PHP seul (le plus leger, recommande)

1. Telecharger le zip "Non Thread Safe" de PHP pour Windows :
   https://windows.php.net/download/ (ex: PHP 8.3 x64 NTS)
2. Dezipper dans `C:\php`
3. Ouvrir une invite de commandes dans le dossier de la demo
   (`vuln-upload-demo`) et lancer :

   ```bash
   C:\php\php.exe -S 0.0.0.0:8080
   ```

4. Depuis la VM (ou une autre machine du lab), ouvrir :
   `http://<IP-de-la-VM>:8080/`

Pas d'installateur, pas de service Windows a configurer : un seul exe,
un seul process, facile a arreter (`Ctrl+C`) et a nettoyer.

### Option B - XAMPP (si tu veux un Apache "comme en prod")

1. Installer XAMPP (Apache + PHP) : https://www.apachefriends.org/
2. Copier le dossier `vuln-upload-demo` dans `C:\xampp\htdocs\`
3. Lancer Apache depuis le panneau de controle XAMPP
4. Ouvrir `http://<IP-de-la-VM>/vuln-upload-demo/`

---

## 2. Structure du projet

```
vuln-upload-demo/
├── index.php          # Page d'accueil - portail "carrieres" fictif (Nexora Group)
├── upload.php         # Handler d'upload - AUCUN controle (la faille)
├── style.css          # Habillage visuel du faux portail RH
├── uploads/            # Dossier ou atterrissent les fichiers uploades
└── payloads/
    └── shell.php      # Webshell minimal utilise pour la demo d'exploitation
```

La page d'accueil simule un vrai portail de candidature ("Nexora Group -
Carrieres") avec une fiche de poste, un formulaire (nom/prenom/email/CV)
et une page de confirmation - pour que la demo soit visuellement credible
face a un client, plutot qu'un simple formulaire nu. Seule une mention
discrete en pied de page rappelle qu'il s'agit d'un environnement de
demo interne.

- **`upload.php`** ne verifie ni l'extension, ni le type MIME, ni le
  contenu du fichier envoye : un fichier `.php` est accepte et stocke
  directement dans `uploads/`, qui est servi par le serveur web.
- **`payloads/shell.php`** est le fichier qu'on va uploader pour simuler
  l'attaquant : une fois depose dans `uploads/`, il permet d'executer des
  commandes systeme via `?cmd=...`.

---

## 3. Scenario de demo (sans CrowdStrike - montrer l'impact)

1. Ouvrir `http://<IP-VM>:8080/`
2. Dans le formulaire, selectionner `payloads/shell.php` et l'envoyer.
   -> Le fichier est accepte sans aucun avertissement et apparait dans
      la liste "Fichiers recus".
3. Cliquer sur le lien `shell.php`, ou ouvrir directement :
   `http://<IP-VM>:8080/uploads/shell.php?cmd=whoami`
4. Montrer que la commande s'execute avec les droits du process PHP
   (`whoami`, `ipconfig`, `dir C:\`, etc.) : c'est une RCE complete.

A ce stade, un attaquant a un acces commande persistant sur le serveur.

## 4. Scenario avec CrowdStrike Falcon (montrer la detection/protection)

Avec le sensor Falcon installe sur la VM, refaire exactement les memes
etapes et montrer dans la console Falcon (ou via les alertes locales) :

- **Detection a l'ecriture** : alerte sur le depot d'un fichier `.php`
  dans un repertoire servi par le web server (comportement de type
  "webshell drop").
- **Detection a l'execution** : alerte quand `php.exe` (ou `httpd.exe`
  / `w3wp.exe` selon l'option choisie) spawn un process enfant anormal
  (`cmd.exe`, `powershell.exe`, `whoami.exe`...) - signature classique
  d'exploitation de webshell.
- **Blocage (Prevention Policy)** : avec les politiques de prevention
  activees, Falcon peut bloquer l'execution du process enfant malveillant
  avant meme que la commande ne reussisse, et mettre le fichier en
  quarantaine.

Points a mettre en avant pendant la demo :
- La vulnerabilite applicative (upload non filtre) n'est **pas corrigee** :
  c'est volontaire, pour montrer que meme une appli mal codee reste
  protegee grace a la detection comportementale au niveau process/EDR.
- CrowdStrike ne corrige pas le code, il **casse la chaine d'attaque**
  au moment ou l'exploitation tente de se traduire en action systeme
  (execution de commande, creation de process, acces fichier).

---

## 5. Nettoyage apres la demo

- Supprimer le contenu de `uploads/` (sauf `.gitkeep`) pour repartir propre.
- Arreter le serveur PHP (`Ctrl+C`) ou le service Apache (XAMPP).
- Idealement, revert/snapshot la VM a un etat propre avant/apres chaque
  session de demo.

---

## 6. Pour aller plus loin (variantes faciles a montrer ensuite)

- **Polyglotte image/PHP** : renommer `shell.php` en `shell.php.jpg` puis
  en `shell.php` cote serveur, ou utiliser un vrai JPEG avec du code PHP
  injecte dans les metadonnees, pour montrer le contournement d'un simple
  controle d'extension cote client.
- **Blacklist faible** : modifier `upload.php` pour bloquer seulement
  `.php` (facilement contournable avec `.phtml`, `.php5`, etc.) et montrer
  que la detection EDR reste efficace meme quand le filtre applicatif est
  contourne.
