<?php
// ============================================================
//  DEMO VOLONTAIREMENT VULNERABLE - usage interne uniquement
//  But : montrer une faille d'upload de fichier non filtree
//  (CWE-434 - Unrestricted Upload of File with Dangerous Type)
//  et illustrer comment un EDR comme CrowdStrike Falcon
//  detecte/bloque l'exploitation (webshell -> execution process).
//
//  NE JAMAIS exposer ce code sur un reseau non isole / Internet.
// ============================================================
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nexora Group - Carrieres</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">NEXORA<span>GROUP</span></div>
        <nav>
            <a href="#">Accueil</a>
            <a href="#">Nos metiers</a>
            <a href="#">Offres d'emploi</a>
            <a href="#">Contact</a>
        </nav>
    </header>

    <div class="hero">
        <h1>Rejoignez nos equipes</h1>
        <p>Postulez en ligne en quelques minutes - reponse sous 5 jours ouvres</p>
    </div>

    <div class="container">
        <div class="card">
            <h2>Ingenieur(e) Support Infrastructure</h2>
            <div class="job-meta">
                <span>Contrat : <strong>CDI</strong></span>
                <span>Localisation : <strong>Lyon / Remote partiel</strong></span>
                <span>Reference : <strong>NX-2026-0412</strong></span>
            </div>
            <p>
                Au sein de la DSI, vous assurez le support de niveau 2/3 de notre
                infrastructure interne et participez aux projets d'amelioration
                continue de nos environnements de production.
            </p>
        </div>

        <div class="card">
            <h2>Formulaire de candidature</h2>
            <form action="upload.php" method="POST" enctype="multipart/form-data">
                <label for="nom">Nom</label>
                <input type="text" id="nom" name="nom" placeholder="Votre nom">

                <label for="prenom">Prenom</label>
                <input type="text" id="prenom" name="prenom" placeholder="Votre prenom">

                <label for="email">Adresse email</label>
                <input type="email" id="email" name="email" placeholder="vous@exemple.com">

                <label for="cv_file">CV (PDF, DOC, DOCX)</label>
                <input type="file" id="cv_file" name="cv_file">
                <div class="file-hint">Format recommande : PDF - 5 Mo maximum</div>

                <button type="submit" class="submit-btn">Envoyer ma candidature</button>
            </form>
        </div>

        <?php
        // Liste les fichiers deja presents dans uploads/
        $dir = __DIR__ . '/uploads';
        $files = array_diff(scandir($dir), ['.', '..', '.gitkeep']);
        if (count($files) > 0) {
            echo "<div class='card'><h2>Candidatures recues</h2><ul class='received-list'>";
            foreach ($files as $f) {
                echo "<li><a href='uploads/" . htmlspecialchars($f) . "' target='_blank'>" . htmlspecialchars($f) . "</a></li>";
            }
            echo "</ul></div>";
        }
        ?>
    </div>

    <footer>
        Nexora Group &copy; 2026 - Espace carrieres &middot; Environnement de demonstration interne, non destine a la production
    </footer>
</body>
</html>
