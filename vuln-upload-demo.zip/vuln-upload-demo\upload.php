<?php
// ============================================================
//  HANDLER D'UPLOAD VOLONTAIREMENT VULNERABLE
//  Faille : aucun controle sur l'extension / le type MIME /
//  le contenu du fichier -> un fichier .php peut etre depose
//  et execute directement par le serveur web (RCE via webshell).
//
//  C'est le point que CrowdStrike Falcon doit detecter :
//   1) ecriture d'un .php suspect dans un repertoire web
//   2) execution ulterieure (w3wp.exe / php-cgi.exe / httpd
//      qui spawn cmd.exe ou powershell.exe)
// ============================================================

$uploadDir = __DIR__ . '/uploads/';

$nom = $_POST['nom'] ?? '';
$prenom = $_POST['prenom'] ?? '';
$email = $_POST['email'] ?? '';

if (!isset($_FILES['cv_file']) || $_FILES['cv_file']['error'] !== UPLOAD_ERR_OK) {
    $errorPage = true;
} else {
    $fileName = basename($_FILES['cv_file']['name']);   // pas de sanitation serieuse
    $targetPath = $uploadDir . $fileName;

    // *** VULNERABILITE ***
    // Aucune verification d'extension, de type MIME reel, ni de contenu.
    // Un fichier "shell.php" est accepte et stocke tel quel dans un
    // repertoire servi par le serveur web -> execution directe possible
    // via http://<host>/uploads/shell.php?cmd=whoami
    move_uploaded_file($_FILES['cv_file']['tmp_name'], $targetPath);
    $errorPage = false;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nexora Group - Carrieres</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">NEXORA<span>GROUP</span></div>
        <nav>
            <a href="#">Accueil</a>
            <a href="#">Nos metiers</a>
            <a href="#">Offres d'emploi</a>
            <a href="#">Contact</a>
        </nav>
    </header>

    <div class="hero">
        <h1><?= $errorPage ? "Un probleme est survenu" : "Candidature envoyee" ?></h1>
        <p><?= $errorPage ? "Merci de reessayer votre envoi." : "Merci pour votre interet, notre equipe RH va etudier votre dossier." ?></p>
    </div>

    <div class="container">
        <div class="card">
            <?php if ($errorPage): ?>
                <p>Votre fichier n'a pas pu etre receptionne. Veuillez reessayer.</p>
            <?php else: ?>
                <p>
                    Bonjour <?= htmlspecialchars($prenom . ' ' . $nom) ?>,<br>
                    votre candidature a bien ete enregistree. Un email de confirmation
                    sera envoye a <?= htmlspecialchars($email) ?>.
                </p>
                <p><strong>Document recu :</strong> <?= htmlspecialchars($fileName) ?></p>
            <?php endif; ?>
            <p><a href="index.php">&larr; Retour a l'espace carrieres</a></p>
        </div>
    </div>

    <footer>
        Nexora Group &copy; 2026 - Espace carrieres &middot; Environnement de demonstration interne, non destine a la production
    </footer>
</body>
</html>
