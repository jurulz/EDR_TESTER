<?php
// ============================================================
//  DEMO VOLONTAIREMENT VULNERABLE - usage interne uniquement
//  But : montrer une faille d'upload de fichier non filtree
//  (CWE-434 - Unrestricted Upload of File with Dangerous Type)
//  et illustrer comment un EDR comme CrowdStrike Falcon
//  detecte/bloque l'exploitation (webshell -> execution process).
//
//  NE JAMAIS exposer ce code sur un reseau non isole / Internet.
// ============================================================
require __DIR__ . '/lang.php';
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= t('page_title') ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">NEXORA<span>GROUP</span></div>
        <nav>
            <a href="#"><?= t('nav_home') ?></a>
            <a href="#"><?= t('nav_jobs_area') ?></a>
            <a href="#"><?= t('nav_jobs') ?></a>
            <a href="#"><?= t('nav_contact') ?></a>
            <span class="lang-switch">
                <a href="?lang=fr" class="<?= $lang === 'fr' ? 'active' : '' ?>">FR</a>
                <span class="sep">|</span>
                <a href="?lang=en" class="<?= $lang === 'en' ? 'active' : '' ?>">EN</a>
            </span>
        </nav>
    </header>

    <div class="hero">
        <h1><?= t('hero_title') ?></h1>
        <p><?= t('hero_subtitle') ?></p>
    </div>

    <div class="container">
        <div class="card">
            <h2><?= t('job_title') ?></h2>
            <div class="job-meta">
                <span><?= t('job_contract_label') ?> <strong><?= t('job_contract_value') ?></strong></span>
                <span><?= t('job_location_label') ?> <strong><?= t('job_location_value') ?></strong></span>
                <span><?= t('job_ref_label') ?> <strong>NX-2026-0412</strong></span>
            </div>
            <p><?= t('job_desc') ?></p>
        </div>

        <div class="card">
            <h2><?= t('form_title') ?></h2>
            <form action="upload.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="lang" value="<?= htmlspecialchars($lang) ?>">

                <label for="nom"><?= t('form_lastname') ?></label>
                <input type="text" id="nom" name="nom" placeholder="<?= t('form_lastname_ph') ?>">

                <label for="prenom"><?= t('form_firstname') ?></label>
                <input type="text" id="prenom" name="prenom" placeholder="<?= t('form_firstname_ph') ?>">

                <label for="email"><?= t('form_email') ?></label>
                <input type="email" id="email" name="email" placeholder="vous@exemple.com">

                <label for="cv_file"><?= t('form_cv') ?></label>
                <input type="file" id="cv_file" name="cv_file">
                <div class="file-hint"><?= t('form_hint') ?></div>

                <button type="submit" class="submit-btn"><?= t('form_submit') ?></button>
            </form>
        </div>

        <?php
        // Liste les fichiers deja presents dans uploads/
        $dir = __DIR__ . '/uploads';
        $files = array_diff(scandir($dir), ['.', '..', '.gitkeep']);
        if (count($files) > 0) {
            echo "<div class='card'><h2>" . t('received_title') . "</h2><ul class='received-list'>";
            foreach ($files as $f) {
                echo "<li><a href='uploads/" . htmlspecialchars($f) . "' target='_blank'>" . htmlspecialchars($f) . "</a></li>";
            }
            echo "</ul></div>";
        }
        ?>
    </div>

    <footer>
        <?= t('footer_text') ?>
    </footer>
</body>
</html>
