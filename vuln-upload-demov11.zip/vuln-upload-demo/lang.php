<?php
// Petit helper i18n pour la demo bilingue FR/EN.
// Langue choisie via ?lang=fr|en (persistee en session), defaut: fr.

session_start();

$lang = $_GET['lang'] ?? $_POST['lang'] ?? $_SESSION['lang'] ?? 'fr';
if (!in_array($lang, ['fr', 'en'], true)) {
    $lang = 'fr';
}
$_SESSION['lang'] = $lang;

$STRINGS = [
    'fr' => [
        'nav_home' => 'Accueil',
        'nav_jobs_area' => 'Nos metiers',
        'nav_jobs' => "Offres d'emploi",
        'nav_contact' => 'Contact',
        'hero_title' => 'Rejoignez nos equipes',
        'hero_subtitle' => 'Postulez en ligne en quelques minutes - reponse sous 5 jours ouvres',
        'job_title' => 'Ingenieur(e) Support Infrastructure',
        'job_contract_label' => 'Contrat :',
        'job_contract_value' => 'CDI',
        'job_location_label' => 'Localisation :',
        'job_location_value' => 'Lyon / Remote partiel',
        'job_ref_label' => 'Reference :',
        'job_desc' => "Au sein de la DSI, vous assurez le support de niveau 2/3 de notre infrastructure interne et participez aux projets d'amelioration continue de nos environnements de production.",
        'form_title' => 'Formulaire de candidature',
        'form_lastname' => 'Nom',
        'form_lastname_ph' => 'Votre nom',
        'form_firstname' => 'Prenom',
        'form_firstname_ph' => 'Votre prenom',
        'form_email' => 'Adresse email',
        'form_cv' => 'CV (PDF, DOC, DOCX)',
        'form_hint' => 'Format recommande : PDF - 5 Mo maximum',
        'form_submit' => 'Envoyer ma candidature',
        'received_title' => 'Candidatures recues',
        'footer_text' => 'Nexora Group &copy; 2026 - Espace carrieres &middot; Environnement de demonstration interne, non destine a la production',
        'result_error_title' => 'Un probleme est survenu',
        'result_error_subtitle' => 'Merci de reessayer votre envoi.',
        'result_error_body' => "Votre fichier n'a pas pu etre receptionne. Veuillez reessayer.",
        'result_ok_title' => 'Candidature envoyee',
        'result_ok_subtitle' => 'Merci pour votre interet, notre equipe RH va etudier votre dossier.',
        'result_ok_body' => 'Bonjour %s,<br>votre candidature a bien ete enregistree. Un email de confirmation sera envoye a %s.',
        'result_doc_label' => 'Document recu :',
        'back_link' => '&larr; Retour a l\'espace carrieres',
        'page_title' => 'Nexora Group - Carrieres',
    ],
    'en' => [
        'nav_home' => 'Home',
        'nav_jobs_area' => 'Our professions',
        'nav_jobs' => 'Job openings',
        'nav_contact' => 'Contact',
        'hero_title' => 'Join our teams',
        'hero_subtitle' => 'Apply online in a few minutes - response within 5 business days',
        'job_title' => 'Infrastructure Support Engineer',
        'job_contract_label' => 'Contract:',
        'job_contract_value' => 'Permanent',
        'job_location_label' => 'Location:',
        'job_location_value' => 'Lyon / Partial remote',
        'job_ref_label' => 'Reference:',
        'job_desc' => 'Within the IT department, you provide level 2/3 support for our internal infrastructure and take part in continuous improvement projects for our production environments.',
        'form_title' => 'Application form',
        'form_lastname' => 'Last name',
        'form_lastname_ph' => 'Your last name',
        'form_firstname' => 'First name',
        'form_firstname_ph' => 'Your first name',
        'form_email' => 'Email address',
        'form_cv' => 'Resume (PDF, DOC, DOCX)',
        'form_hint' => 'Recommended format: PDF - 5 MB max',
        'form_submit' => 'Submit my application',
        'received_title' => 'Applications received',
        'footer_text' => 'Nexora Group &copy; 2026 - Careers &middot; Internal demo environment, not intended for production',
        'result_error_title' => 'Something went wrong',
        'result_error_subtitle' => 'Please try sending it again.',
        'result_error_body' => 'Your file could not be received. Please try again.',
        'result_ok_title' => 'Application sent',
        'result_ok_subtitle' => 'Thank you for your interest, our HR team will review your file.',
        'result_ok_body' => 'Hello %s,<br>your application has been successfully registered. A confirmation email will be sent to %s.',
        'result_doc_label' => 'Document received:',
        'back_link' => '&larr; Back to careers page',
        'page_title' => 'Nexora Group - Careers',
    ],
];

function t($key, ...$args) {
    global $STRINGS, $lang;
    $value = $STRINGS[$lang][$key] ?? $key;
    if (count($args) > 0) {
        return vsprintf($value, $args);
    }
    return $value;
}
