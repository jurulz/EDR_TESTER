<#
.SYNOPSIS
    Installe PHP portable (Non Thread Safe, x64) pour faire tourner la demo
    vuln-upload-demo sur Windows 10, sans Docker ni IIS.

.DESCRIPTION
    - Verifie que le Visual C++ Redistributable (requis par PHP pour
      Windows, build "vsNN") est present ; sinon le telecharge depuis
      Microsoft et l'installe silencieusement.
    - Repere automatiquement la derniere version PHP 8.3 NTS x64 sur
      windows.php.net.
    - La telecharge dans un dossier temporaire.
    - La dezippe dans -InstallDir (par defaut C:\php).
    - Verifie l'installation (php.exe -v).

    A executer dans un lab/VM isole, jamais sur un poste de production.

.PARAMETER InstallDir
    Dossier de destination pour PHP. Par defaut : C:\php

.EXAMPLE
    .\setup-php.ps1
    .\setup-php.ps1 -InstallDir "D:\tools\php"
#>

[CmdletBinding()]
param(
    [string]$InstallDir = "C:\php"
)

$ErrorActionPreference = "Stop"

function Write-Step($msg) {
    Write-Host ""
    Write-Host "==> $msg" -ForegroundColor Cyan
}

if (Test-Path (Join-Path $InstallDir "php.exe")) {
    Write-Host "PHP est deja present dans $InstallDir :" -ForegroundColor Yellow
    & (Join-Path $InstallDir "php.exe") -v
    Write-Host "Rien a faire. Supprime ce dossier si tu veux forcer une reinstallation."
    exit 0
}

function Test-VCRedistInstalled {
    # Les builds PHP "vsNN" (vs16 = VS2019, vs17 = VS2022) sont tous lies
    # au meme runtime C++ "v14x", retro/forward-compatible. On regarde la
    # cle standard publiee par le redistributable Microsoft.
    $keys = @(
        "HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes\x64"
    )
    foreach ($key in $keys) {
        $val = Get-ItemProperty -Path $key -ErrorAction SilentlyContinue
        if ($val -and $val.Installed -eq 1) {
            return $true
        }
    }
    return $false
}

Write-Step "Verification du Visual C++ Redistributable (requis par PHP, pas Visual Studio)"

if (Test-VCRedistInstalled) {
    Write-Host "Visual C++ Redistributable deja present." -ForegroundColor Green
} else {
    Write-Host "Visual C++ Redistributable absent sur cette VM : telechargement en cours..." -ForegroundColor Yellow

    $vcRedistUrl = "https://aka.ms/vs/17/release/vc_redist.x64.exe"
    $vcTempDir = Join-Path $env:TEMP "vcredist-setup-$(Get-Random)"
    New-Item -ItemType Directory -Path $vcTempDir -Force | Out-Null
    $vcInstaller = Join-Path $vcTempDir "vc_redist.x64.exe"

    try {
        Invoke-WebRequest -Uri $vcRedistUrl -OutFile $vcInstaller -UseBasicParsing

        Write-Host "Installation silencieuse du Visual C++ Redistributable (necessite les droits admin)..."
        $proc = Start-Process -FilePath $vcInstaller -ArgumentList "/install", "/quiet", "/norestart" -Wait -PassThru
        if ($proc.ExitCode -ne 0 -and $proc.ExitCode -ne 3010) {
            throw "L'installateur vc_redist.x64.exe a retourne le code $($proc.ExitCode)."
        }
        if ($proc.ExitCode -eq 3010) {
            Write-Host "Installe. Un redemarrage est recommande (code 3010) mais pas obligatoire pour cette demo." -ForegroundColor Yellow
        } else {
            Write-Host "Visual C++ Redistributable installe." -ForegroundColor Green
        }
    } finally {
        Remove-Item -Path $vcTempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

Write-Step "Recherche de la derniere version PHP 8.3 (NTS, x64) sur windows.php.net"

$releasesUrl = "https://windows.php.net/downloads/releases/"
try {
    $releasesPage = Invoke-WebRequest -Uri $releasesUrl -UseBasicParsing
} catch {
    throw "Impossible de contacter $releasesUrl. Verifie la connexion Internet de la VM. Detail : $_"
}

# On cherche un lien du type php-8.3.XX-nts-Win32-vs16-x64.zip (pas debug-pack, pas devel-pack)
$pattern = 'php-8\.3\.\d+-nts-Win32-vs\d+-x64\.zip'
$match = [regex]::Matches($releasesPage.Content, $pattern) |
    Select-Object -ExpandProperty Value -Unique |
    Sort-Object { [version]([regex]::Match($_, '\d+\.\d+\.\d+').Value) } -Descending |
    Select-Object -First 1

if (-not $match) {
    # Repli : version connue au moment de l'ecriture de ce script.
    $match = "php-8.3.36-nts-Win32-vs16-x64.zip"
    Write-Host "Aucune version detectee automatiquement, repli sur $match" -ForegroundColor Yellow
}

$zipName = $match
$downloadUrl = "https://windows.php.net/downloads/releases/$zipName"
Write-Host "Version retenue : $zipName"
Write-Host "URL : $downloadUrl"

$tempDir = Join-Path $env:TEMP "php-setup-$(Get-Random)"
New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
$zipPath = Join-Path $tempDir $zipName

Write-Step "Telechargement de $zipName vers $zipPath"
Invoke-WebRequest -Uri $downloadUrl -OutFile $zipPath -UseBasicParsing

Write-Step "Extraction vers $InstallDir"
New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
Expand-Archive -Path $zipPath -DestinationPath $InstallDir -Force

Write-Step "Nettoyage des fichiers temporaires"
Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue

$phpExe = Join-Path $InstallDir "php.exe"
if (-not (Test-Path $phpExe)) {
    throw "L'extraction a echoue : $phpExe introuvable."
}

# Active un php.ini minimal a partir du modele "development" fourni dans le zip
$iniDev = Join-Path $InstallDir "php.ini-development"
$ini = Join-Path $InstallDir "php.ini"
if ((Test-Path $iniDev) -and -not (Test-Path $ini)) {
    Copy-Item $iniDev $ini
}

Write-Step "Verification"
& $phpExe -v

Write-Host ""
Write-Host "PHP installe dans $InstallDir" -ForegroundColor Green
Write-Host "Lance maintenant .\start-demo.ps1 depuis le dossier de la demo pour demarrer le serveur."
