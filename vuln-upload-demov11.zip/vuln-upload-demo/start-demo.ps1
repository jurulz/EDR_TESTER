<#
.SYNOPSIS
    Lance le serveur PHP integre pour la demo vuln-upload-demo.

.DESCRIPTION
    A executer depuis le dossier de la demo (ou n'importe ou, le script
    se positionne lui-meme sur son propre dossier). Suppose que PHP a
    deja ete installe via .\setup-php.ps1 (ou manuellement dans C:\php).

.PARAMETER PhpDir
    Dossier contenant php.exe. Par defaut : C:\php

.PARAMETER Port
    Port d'ecoute du serveur. Par defaut : 8080

.PARAMETER BindAll
    Si present, ecoute sur 0.0.0.0 (accessible depuis d'autres machines
    du lab). Par defaut, ecoute uniquement sur 127.0.0.1.

.EXAMPLE
    .\start-demo.ps1
    .\start-demo.ps1 -Port 8081 -BindAll
#>

[CmdletBinding()]
param(
    [string]$PhpDir = "C:\php",
    [int]$Port = 8080,
    [switch]$BindAll
)

$ErrorActionPreference = "Stop"

$phpExe = Join-Path $PhpDir "php.exe"
if (-not (Test-Path $phpExe)) {
    Write-Host "php.exe introuvable dans $PhpDir." -ForegroundColor Red
    Write-Host "Lance d'abord .\setup-php.ps1 pour installer PHP, ou passe -PhpDir si PHP est ailleurs."
    exit 1
}

# Se positionne sur le dossier du script (la demo elle-meme)
Set-Location -Path $PSScriptRoot

$bindAddress = if ($BindAll) { "0.0.0.0" } else { "127.0.0.1" }

Write-Host "Demarrage du serveur PHP de demo sur http://$($bindAddress):$Port/" -ForegroundColor Cyan
Write-Host "Ctrl+C pour arreter."
if ($BindAll) {
    Write-Host "ATTENTION : le serveur ecoute sur toutes les interfaces (0.0.0.0)." -ForegroundColor Yellow
    Write-Host "A n'utiliser que sur un reseau de lab isole, jamais expose sur Internet / prod." -ForegroundColor Yellow
}
Write-Host ""

& $phpExe -S "$($bindAddress):$Port"
