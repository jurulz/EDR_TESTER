<?php
// ============================================================
//  HANDLER D'UPLOAD VOLONTAIREMENT VULNERABLE
//  Faille : aucun controle sur l'extension / le type MIME /
//  le contenu du fichier -> un fichier .php peut etre depose
//  et execute directement par le serveur web (RCE via webshell).
//
//  C'est le point que CrowdStrike Falcon doit detecter :
//   1) ecriture d'un .php suspect dans un repertoire web
//   2) execution ulterieure (w3wp.exe / php-cgi.exe / httpd
//      qui spawn cmd.exe ou powershell.exe)
// ============================================================
require __DIR__ . '/lang.php';

$uploadDir = __DIR__ . '/uploads/';

$nom = $_POST['nom'] ?? '';
$prenom = $_POST['prenom'] ?? '';
$email = $_POST['email'] ?? '';

if (!isset($_FILES['cv_file']) || $_FILES['cv_file']['error'] !== UPLOAD_ERR_OK) {
    $errorPage = true;
} else {
    $fileName = basename($_FILES['cv_file']['name']);   // pas de sanitation serieuse
    $targetPath = $uploadDir . $fileName;

    // *** VULNERABILITE ***
    // Aucune verification d'extension, de type MIME reel, ni de contenu.
    // Un fichier "shell.php" est accepte et stocke tel quel dans un
    // repertoire servi par le serveur web -> execution directe possible
    // via http://<host>/uploads/shell.php?cmd=whoami
    move_uploaded_file($_FILES['cv_file']['tmp_name'], $targetPath);
    $errorPage = false;
}
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= t('page_title') ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">NEXORA<span>GROUP</span></div>
        <nav>
            <a href="#"><?= t('nav_home') ?></a>
            <a href="#"><?= t('nav_jobs_area') ?></a>
            <a href="#"><?= t('nav_jobs') ?></a>
            <a href="#"><?= t('nav_contact') ?></a>
            <span class="lang-switch">
                <a href="?lang=fr" class="<?= $lang === 'fr' ? 'active' : '' ?>">FR</a>
                <span class="sep">|</span>
                <a href="?lang=en" class="<?= $lang === 'en' ? 'active' : '' ?>">EN</a>
            </span>
        </nav>
    </header>

    <div class="hero">
        <h1><?= $errorPage ? t('result_error_title') : t('result_ok_title') ?></h1>
        <p><?= $errorPage ? t('result_error_subtitle') : t('result_ok_subtitle') ?></p>
    </div>

    <div class="container">
        <div class="card">
            <?php if ($errorPage): ?>
                <p><?= t('result_error_body') ?></p>
            <?php else: ?>
                <p><?= t('result_ok_body', htmlspecialchars($prenom . ' ' . $nom), htmlspecialchars($email)) ?></p>
                <p><strong><?= t('result_doc_label') ?></strong> <?= htmlspecialchars($fileName) ?></p>
            <?php endif; ?>
            <p><a href="index.php?lang=<?= htmlspecialchars($lang) ?>"><?= t('back_link') ?></a></p>
        </div>
    </div>

    <footer>
        <?= t('footer_text') ?>
    </footer>
</body>
</html>
